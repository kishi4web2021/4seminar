from django.contrib import admin
from .models import Board
#ボードモデルの追加
admin.site.register(Board)
# Register your models here.
